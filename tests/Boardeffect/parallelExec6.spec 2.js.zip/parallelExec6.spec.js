module.exports = {
    workers: 4, // Number of parallel workers
    use: { browserName: 'chromium' }
}

const { test, expect } = require('@playwright/test')
const XLSX = require('xlsx')

test.setTimeout(500000)

test.describe.parallel('testing URLs parallelly for 404s', () => {

    //const fileName = '/Users/mayurwani/Desktop/Mayur_work/Playwright/Proj2_VScode_ext/testsInitialData/Boardeffect_sampleTestData.xlsx'

    const fileName = './testsInitialData/Boardeffect_sampleTestData_ProdURLs.xlsx'
    const boardeffectWorkbook = XLSX.readFile(fileName)
    const sheetNames = boardeffectWorkbook.SheetNames

    //console.log(sheetNames)

    for (const region of sheetNames) {
        const regionJsonSheet = boardeffectWorkbook.Sheets[region]
        const regionJson = XLSX.utils.sheet_to_json(regionJsonSheet)
        const regionURLlist = regionJson.map(row => row['URL'])

        //console.log(regionURLlist)

        for (const blogUrl of regionURLlist) {

            test('testing for region > ' + region + ' > URL > ' + blogUrl, async ({ page }) => {

                // navigate to the page URL
                await page.goto(blogUrl, { waitUntil: 'networkidle' })

                // handle allow cookies pop-up
                const allowCookieLocator = page.locator('//span[contains(text(),"Allow All Cookies")]')
                if (await allowCookieLocator.isVisible()) {
                    console.log('Cookie button found')
                    await allowCookieLocator.click()
                    console.log('Cookie button clicked once')
                }

                // handle intermittently occuring larger cookies panel in case of multiple workers
                if (await page.locator('(//img[@alt="BoardEffect Logo"])[1]').isVisible()) {
                    console.log('Boardeffect logo is visible')
                } else {
                    console.log('Boardeffect logo is NOT visible')
                    await page.screenshot({path: `./testsExportData/failed_${blogUrl}_.png`})
                    if (await allowCookieLocator.isVisible()) {
                        console.log('Cookie button found second time')
                        await allowCookieLocator.click()
                        console.log('Boardeffect logo was NOT visible, clicked allow cookies button again!')
                    }
                }

                // To check if the page content is loaded or boardeffect 404 page is displayed
                if (await page.locator('(//img[@alt="fb logo"])[1]').isVisible()){
                    console.log("fb logo was found, Test PASSED!")
                }else{
                    await expect(page.locator('//h1[normalize-space()="404"]')).toBeVisible()
                    console.log('boardeffect 404 was observed')
                    test.fail()
                }
            })
        }
    }
})